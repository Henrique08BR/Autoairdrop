var configtemplate = [
    {"cellcoin"  : {"Authorization" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"cexio" : {"init_data" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"hamster" : {"authorization" : "Authorization data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"hotgame" : {"accid" : "Account ID", "Authorization" : "Authorization data", "init_data" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"memefi" : {"init_data" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"timefarm" : {"init_data" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"spinner" : {"init_data" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"tapswap" : {"Authorization" : "Authorization data", "init_data" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"yescoin" : {"token" : "Authorization data", "Proxy" : "Proxy address", "type" : "Proxy type"}},
    {"blum" : {"Authorization" : "Authorization data", "init_data" : "Telegram init data", "Proxy" : "Proxy address", "type" : "Proxy type"}}
]

var common_config = {
    "Proxy" : "Proxy address",
    "type" : "Proxy type",
    "ua"  : "User agent"
}